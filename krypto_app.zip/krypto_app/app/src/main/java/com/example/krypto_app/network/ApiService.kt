package com.example.krypto_app.network

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET

/**
 * Interface defining the API endpoints for the application.
 * Each method corresponds to an API endpoint and returns a Call object.
 */
interface ApiService {

    /**
     * Fetches the filtered top 100 coins data from the API.
     * The response is expected to be a CSV file.
     * @return A Call object containing the response body.
     */
    @GET("{YOUR FOLDER NAME}/api.php?file=filtered_top_100_coins")
    fun getFilteredTop100Coins(): Call<ResponseBody>

    /**
     * Fetches the new cryptocurrencies data from the API.
     * The response is expected to be a CSV file.
     * @return A Call object containing the response body.
     */
    @GET("{YOUR FOLDER NAME}/api.php?file=new_cryptocurrencies")
    fun getNewCryptocurrencies(): Call<ResponseBody>

    /**
     * Fetches the Twitter screenshots data from the API.
     * The response is expected to be a ZIP file containing images.
     * @return A Call object containing the response body.
     */
    @GET("{YOUR FOLDER NAME}/api.php?file=twitter_screenshots")
    fun getTwitterScreenshots(): Call<ResponseBody>
}
