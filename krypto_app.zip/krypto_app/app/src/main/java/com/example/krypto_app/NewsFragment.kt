package com.example.krypto_app

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.krypto_app.network.RetrofitClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class NewsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_news, container, false)
        val linearLayout: LinearLayout = view.findViewById(R.id.linearLayout)

        // Fetch the zip file containing images from the API
        RetrofitClient.apiService.getTwitterScreenshots().enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    val zipInputStream = response.body()?.byteStream()
                    if (zipInputStream != null) {
                        // Extract images from the zip file and display them
                        val extractedFiles = extractZipToInternalStorage(zipInputStream)
                        displayImages(extractedFiles, linearLayout)
                    } else {
                        Toast.makeText(requireContext(), "No data received", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to load data", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                t.printStackTrace()
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })

        return view
    }

    /**
     * Extracts the contents of a zip file to the app's internal storage.
     * @param zipInputStream The input stream of the zip file.
     * @return A list of extracted files.
     */
    private fun extractZipToInternalStorage(zipInputStream: InputStream): List<File> {
        val extractedFiles = mutableListOf<File>()
        val outputDir = requireContext().cacheDir // Temporary directory for extracted files

        ZipInputStream(zipInputStream).use { zis ->
            var entry: ZipEntry?
            while (zis.nextEntry.also { entry = it } != null) {
                val fileName = entry?.name ?: continue
                val outputFile = File(outputDir, fileName)

                // Write the contents of the zip entry to a file
                FileOutputStream(outputFile).use { fos ->
                    val buffer = ByteArray(1024)
                    var length: Int
                    while (zis.read(buffer).also { length = it } > 0) {
                        fos.write(buffer, 0, length)
                    }
                }

                extractedFiles.add(outputFile)
                zis.closeEntry()
            }
        }

        return extractedFiles
    }

    /**
     * Displays a list of images in a LinearLayout.
     * @param files The list of image files to display.
     * @param linearLayout The LinearLayout where the images will be added.
     */
    private fun displayImages(files: List<File>, linearLayout: LinearLayout) {
        files.forEach { file ->
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            val imageView = ImageView(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 16, 0, 16)
                }
                setImageBitmap(bitmap)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            linearLayout.addView(imageView)
        }
    }
}
