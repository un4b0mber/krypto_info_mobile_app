package com.example.krypto_app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    // Stack to store the history of fragments for navigation
    private val fragmentStack = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the toolbar and set it as the action bar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Cryptify" // Set the title of the toolbar

        // Initialize the bottom navigation bar
        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottom_navigation)

        // Load icons for the bottom navigation menu from the assets folder
        val assetManager = assets
        try {
            val newsInputStream = assetManager.open("news.png")
            val newsBitmap = BitmapFactory.decodeStream(newsInputStream)
            bottomNavigation.menu.findItem(R.id.nav_news).icon =
                BitmapDrawable(resources, Bitmap.createScaledBitmap(newsBitmap, 72, 72, true))
            newsInputStream.close()
        } catch (e: Exception) {
            e.printStackTrace() // Handle missing news.png file
        }

        try {
            val newInputStream = assetManager.open("new.png")
            val newBitmap = BitmapFactory.decodeStream(newInputStream)
            bottomNavigation.menu.findItem(R.id.nav_new).icon =
                BitmapDrawable(resources, Bitmap.createScaledBitmap(newBitmap, 72, 72, true))
            newInputStream.close()
        } catch (e: Exception) {
            e.printStackTrace() // Handle missing new.png file
        }

        try {
            val allTimeInputStream = assetManager.open("all_time.png")
            val allTimeBitmap = BitmapFactory.decodeStream(allTimeInputStream)
            bottomNavigation.menu.findItem(R.id.nav_all_time).icon =
                BitmapDrawable(resources, Bitmap.createScaledBitmap(allTimeBitmap, 72, 72, true))
            allTimeInputStream.close()
        } catch (e: Exception) {
            e.printStackTrace() // Handle missing all_time.png file
        }

        // Set up a listener for bottom navigation item selection
        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            navigateToFragment(item.itemId, true) // Navigate to the selected fragment
            true
        }

        // Set the default fragment to be displayed on app launch
        navigateToFragment(R.id.nav_news, true)
    }

    /**
     * Navigates to the specified fragment.
     * @param itemId The ID of the menu item corresponding to the fragment.
     * @param addToStack Whether to add the fragment to the navigation stack.
     */
    private fun navigateToFragment(itemId: Int, addToStack: Boolean) {
        // Determine the fragment to display based on the selected menu item
        val selectedFragment: Fragment = when (itemId) {
            R.id.nav_news -> NewsFragment()
            R.id.nav_new -> NewFragment()
            R.id.nav_all_time -> AllTimeFragment()
            else -> NewsFragment()
        }

        // Replace the current fragment with the selected fragment
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, selectedFragment)
            .commit()

        // Add the fragment to the stack if required
        if (addToStack) {
            fragmentStack.add(itemId)
        }
    }
}
