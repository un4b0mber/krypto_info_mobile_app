package com.example.krypto_app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.graphics.LinearGradient
import android.graphics.Shader
import androidx.core.content.ContextCompat // Import ContextCompat for backward compatibility
import com.example.krypto_app.models.AllTimeCoin

/**
 * Adapter for displaying a list of all-time coins in a RecyclerView.
 * Handles the binding of data to the views and supports expandable items.
 */
class AllTimeAdapter(
    private val coins: List<AllTimeCoin> // List of all-time coins to display
) : RecyclerView.Adapter<AllTimeAdapter.ViewHolder>() {

    // Set to track expanded positions for expandable items
    private val expandedPositions = mutableSetOf<Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate the layout for each item in the RecyclerView
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_all_time_coin, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Bind the data for the current position
        val coin = coins[position]
        holder.bind(coin, position)
    }

    override fun getItemCount(): Int = coins.size // Return the total number of items

    /**
     * ViewHolder class to hold and manage the views for each item.
     */
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        private val priceTextView: TextView = itemView.findViewById(R.id.priceTextView)
        private val volumeTextView: TextView = itemView.findViewById(R.id.volumeTextView)
        private val additionalDataLayout: LinearLayout = itemView.findViewById(R.id.additionalDataLayout)

        /**
         * Binds the data to the views and handles expand/collapse functionality.
         * @param coin The AllTimeCoin object containing the data.
         * @param position The position of the item in the list.
         */
        fun bind(coin: AllTimeCoin, position: Int) {
            nameTextView.text = coin.name

            // Apply a gradient color to the text
            val paint = nameTextView.paint
            val width = paint.measureText(coin.name)
            val shader = LinearGradient(
                0f, 0f, width, nameTextView.textSize,
                ContextCompat.getColor(itemView.context, R.color.icon_green), // Use ContextCompat.getColor
                ContextCompat.getColor(itemView.context, R.color.icon_green_light), // Use ContextCompat.getColor
                Shader.TileMode.CLAMP
            )
            nameTextView.paint.shader = shader

            priceTextView.text = "Price: ${coin.totalVolume}" // Display the price
            volumeTextView.text = "Volume: ${coin.marketCap}" // Display the volume

            // Clear any previous additional data
            additionalDataLayout.removeAllViews()

            // Add additional data as key-value pairs
            coin.additionalData.forEach { (key, value) ->
                val textView = TextView(itemView.context).apply {
                    text = "$key: $value"
                    textSize = 14f
                    setTextColor(ContextCompat.getColor(itemView.context, R.color.text_white)) // Use ContextCompat.getColor
                }
                additionalDataLayout.addView(textView)
            }

            // Handle expand/collapse functionality
            val isExpanded = expandedPositions.contains(position)
            additionalDataLayout.visibility = if (isExpanded) View.VISIBLE else View.GONE

            itemView.setOnClickListener {
                if (isExpanded) {
                    expandedPositions.remove(position)
                } else {
                    expandedPositions.add(position)
                }
                notifyItemChanged(position) // Notify the adapter to refresh the item
            }
        }
    }
}
