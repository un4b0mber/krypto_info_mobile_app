package com.example.krypto_app

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/**
 * SplashActivity is the entry point of the application.
 * It displays a splash screen with a logo and transitions to MainActivity after a delay.
 */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Load the splash logo from the assets folder
        val splashLogo: ImageView = findViewById(R.id.splashLogo)
        val assetManager = assets
        try {
            // Open the logo.png file from the assets folder
            val inputStream = assetManager.open("logo.png")
            val bitmap = BitmapFactory.decodeStream(inputStream)
            splashLogo.setImageBitmap(bitmap) // Set the loaded bitmap as the ImageView's content
            inputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
            // Handle the case where the logo file is missing
            splashLogo.setImageResource(R.drawable.ic_launcher) // Set a default icon as a fallback
        }

        // Transition to MainActivity after a 2-second delay
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java)) // Start MainActivity
            finish() // Close SplashActivity so it is not accessible via the back button
        }, 2000) // Delay duration in milliseconds
    }
}
