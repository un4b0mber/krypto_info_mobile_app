package com.example.krypto_app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.krypto_app.network.RetrofitClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.BufferedReader
import java.io.InputStreamReader

data class Cryptocurrency(
    val name: String,
    val price: String,
    val volume: String,
    val additionalData: Map<String, String>
)

class NewFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_new, container, false)
        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)

        // Fetch data from the API
        RetrofitClient.apiService.getNewCryptocurrencies().enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    val csvData = response.body()?.string()
                    if (csvData != null) {
                        val cryptocurrencies = parseCsvToCryptocurrencies(csvData)
                        recyclerView.layoutManager = LinearLayoutManager(requireContext())
                        recyclerView.adapter = CryptocurrencyAdapter(cryptocurrencies)
                    } else {
                        Toast.makeText(requireContext(), "No data received", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to load data", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                t.printStackTrace()
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })

        return view
    }

    private fun parseCsvToCryptocurrencies(csvData: String): List<Cryptocurrency> {
        val cryptocurrencies = mutableListOf<Cryptocurrency>()
        val reader = BufferedReader(InputStreamReader(csvData.byteInputStream()))
        val headers = reader.readLine()?.split(",") ?: emptyList() // Read headers
        reader.forEachLine { line ->
            val columns = line.split(",")
            if (columns.size >= 3) {
                val additionalData = headers.drop(3).zip(columns.drop(3)).toMap()
                cryptocurrencies.add(
                    Cryptocurrency(
                        name = columns[0], // Correctly map the name
                        price = columns[2], // Correctly map the price
                        volume = columns[3], // Correctly map the volume
                        additionalData = additionalData
                    )
                )
            }
        }
        return cryptocurrencies
    }
}
