package com.example.krypto_app.network

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Singleton object to configure and provide a Retrofit client instance.
 * This client is used to make API calls to the server.
 */
object RetrofitClient {

    // Base URL for the API endpoints
    private const val BASE_URL = "HERE GOES THE BASE URL ON THE NGROK SERVER AND REMEBER TO ADD '/' AT THE END"

    // Gson instance configured to be lenient for parsing JSON responses
    private val gson: Gson = GsonBuilder()
        .setLenient() // Allows parsing of non-standard JSON responses
        .create()

    /**
     * Lazy-initialized Retrofit instance with the configured base URL and Gson converter.
     * Provides an implementation of the ApiService interface.
     */
    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL) // Set the base URL for the API
            .addConverterFactory(GsonConverterFactory.create(gson)) // Add Gson converter for JSON parsing
            .build()
            .create(ApiService::class.java) // Create an implementation of the ApiService interface
    }
}
