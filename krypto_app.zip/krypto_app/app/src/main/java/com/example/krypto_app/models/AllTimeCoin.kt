package com.example.krypto_app.models

/**
 * Data class representing an all-time coin.
 * @param name The name of the coin.
 * @param marketCap The market capitalization of the coin.
 * @param totalVolume The total trading volume of the coin.
 * @param additionalData A map containing additional key-value data about the coin.
 */
data class AllTimeCoin(
    val name: String,
    val marketCap: String,
    val totalVolume: String,
    val additionalData: Map<String, String>
)
