package com.example.krypto_app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.krypto_app.models.AllTimeCoin // Import the AllTimeCoin class
import com.example.krypto_app.network.RetrofitClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Fragment to display a list of all-time coins.
 * Fetches data from the API and displays it in a RecyclerView.
 */
class AllTimeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_all_time, container, false)
        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)

        // Fetch data from the API
        RetrofitClient.apiService.getFilteredTop100Coins().enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    val csvData = response.body()?.string()
                    if (csvData != null) {
                        // Parse the CSV data and display it in the RecyclerView
                        val coins = parseCsvToAllTimeCoins(csvData)
                        recyclerView.layoutManager = LinearLayoutManager(requireContext())
                        recyclerView.adapter = AllTimeAdapter(coins)
                    } else {
                        Toast.makeText(requireContext(), "No data received", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to load data", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                t.printStackTrace()
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })

        return view
    }

    /**
     * Parses CSV data into a list of AllTimeCoin objects.
     * @param csvData The raw CSV data as a string.
     * @return A list of AllTimeCoin objects.
     */
    private fun parseCsvToAllTimeCoins(csvData: String): List<AllTimeCoin> {
        val coins = mutableListOf<AllTimeCoin>()
        val reader = BufferedReader(InputStreamReader(csvData.byteInputStream()))
        val headers = reader.readLine()?.split(",") ?: emptyList() // Read headers
        reader.forEachLine { line ->
            val columns = line.split(",")
            if (columns.size >= 3) {
                // Map additional data from the CSV
                val additionalData = headers.drop(3).zip(columns.drop(3)).toMap()
                coins.add(
                    AllTimeCoin(
                        name = columns[0], // Name of the coin
                        marketCap = columns[3], // Market capitalization
                        totalVolume = columns[4], // Total volume
                        additionalData = additionalData // Additional data as key-value pairs
                    )
                )
            }
        }
        return coins
    }
}
