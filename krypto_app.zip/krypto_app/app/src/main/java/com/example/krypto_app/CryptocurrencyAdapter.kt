package com.example.krypto_app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.graphics.LinearGradient
import android.graphics.Shader

/**
 * Adapter for displaying a list of cryptocurrencies in a RecyclerView.
 * Handles the binding of data to the views and supports expandable items.
 */
class CryptocurrencyAdapter(
    private val cryptocurrencies: List<Cryptocurrency> // List of cryptocurrencies to display
) : RecyclerView.Adapter<CryptocurrencyAdapter.ViewHolder>() {

    // Set to track expanded positions for expandable items
    private val expandedPositions = mutableSetOf<Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate the layout for each item in the RecyclerView
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cryptocurrency, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Bind the data for the current position
        val cryptocurrency = cryptocurrencies[position]
        holder.bind(cryptocurrency, position)
    }

    override fun getItemCount(): Int = cryptocurrencies.size // Return the total number of items

    /**
     * ViewHolder class to hold and manage the views for each item.
     */
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        private val priceTextView: TextView = itemView.findViewById(R.id.priceTextView)
        private val volumeTextView: TextView = itemView.findViewById(R.id.volumeTextView)
        private val additionalDataLayout: LinearLayout = itemView.findViewById(R.id.additionalDataLayout)

        /**
         * Binds the data to the views and handles expand/collapse functionality.
         * @param cryptocurrency The Cryptocurrency object containing the data.
         * @param position The position of the item in the list.
         */
        fun bind(cryptocurrency: Cryptocurrency, position: Int) {
            // Set the name of the cryptocurrency
            nameTextView.text = cryptocurrency.name

            // Apply a gradient color to the text
            val paint = nameTextView.paint
            val width = paint.measureText(cryptocurrency.name)
            val shader = LinearGradient(
                0f, 0f, width, nameTextView.textSize,
                itemView.context.getColor(R.color.icon_green),
                itemView.context.getColor(R.color.icon_green_light),
                Shader.TileMode.CLAMP
            )
            nameTextView.paint.shader = shader

            // Set the price and volume of the cryptocurrency
            priceTextView.text = "Price: ${cryptocurrency.price}"
            volumeTextView.text = "Volume: ${cryptocurrency.volume}"

            // Clear any previous additional data
            additionalDataLayout.removeAllViews()

            // Add additional data as key-value pairs
            cryptocurrency.additionalData.forEach { (key, value) ->
                val textView = TextView(itemView.context).apply {
                    text = "$key: $value"
                    textSize = 14f
                    setTextColor(itemView.context.getColor(R.color.text_white)) // Set text color to white
                }
                additionalDataLayout.addView(textView)
            }

            // Handle expand/collapse functionality
            val isExpanded = expandedPositions.contains(position)
            additionalDataLayout.visibility = if (isExpanded) View.VISIBLE else View.GONE
            priceTextView.visibility = if (isExpanded) View.GONE else View.VISIBLE
            volumeTextView.visibility = if (isExpanded) View.GONE else View.VISIBLE

            // Toggle expand/collapse on item click
            itemView.setOnClickListener {
                if (isExpanded) {
                    expandedPositions.remove(position)
                } else {
                    expandedPositions.add(position)
                }
                notifyItemChanged(position) // Notify the adapter to refresh the item
            }
        }
    }
}
